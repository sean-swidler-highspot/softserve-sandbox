$(function() {
  $('.nav-user-img, .nav-user-info').click(function() {
    $('.nav-user-control').toggle();
    console.log('Click');
  });
});
